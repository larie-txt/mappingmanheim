## Patch Variables:

* __Brightness__ ```Number``` (default Value: `0.22`)
* __ChromaticAberration__ ```Number``` (default Value: `0`)
* __Color__ ```Texture```
* __Contrast__ ```Number``` (default Value: `0.35`)
* __Feedback__ ```Number``` (default Value: `0.5`)
* __FeedbackMode__ ```Number```
* __Fog__ ```Number``` (default Value: `0.51`)
* __FogColor__ ```Array```
* __FogFar__ ```Number```
* __FogNear__ ```Number```
* __Glow__ ```Number``` (default Value: `0.53`)
* __Height__ ```Number```
* __Noise__ ```Number``` (default Value: `0.47`)
* __NoiseAmount__ ```Number``` (default Value: `0.08`)
* __NoiseMax__ ```Number``` (default Value: `0.05`)
* __NoiseMin__ ```Number``` (default Value: `0`)
* __Opacity__ ```Number```
* __PointSize__ ```Texture```
* __PointSizeMax__ ```Number``` (default Value: `0.42`)
* __PointSizeMin__ ```Number``` (default Value: `0.03`)
* __Position__ ```Texture```
* __PostProcess__ ```Texture```
* __PosYMax__ ```Number``` (default Value: `3.16`)
* __PosYMin__ ```Number``` (default Value: `0`)
* __RadiusMax__ ```Number``` (default Value: `0.01`)
* __RadiusMin__ ```Number``` (default Value: `0`)
* __Reflections__ ```Number```
* __RenderColor__ ```Texture```
* __RenderDepth__ ```Texture```
* __RotX__ ```Number```
* __RotXMax__ ```Number``` (default Value: `-3.44`)
* __RotXMin__ ```Number``` (default Value: `-3.18`)
* __RotY__ ```Number```
* __Round__ ```Number```
* __ScaleByDistance__ ```Number``` (default Value: `0`)
* __ScaleMax__ ```Number``` (default Value: `1.94`)
* __ScaleMin__ ```Number``` (default Value: `0`)
* __Sharpen__ ```Number``` (default Value: `0.23`)
* __SizeAnimate__ ```Number```
* __SSAO__ ```Number```
* __Vibrance__ ```Number``` (default Value: `-0.28`)
* __Vignette__ ```Number``` (default Value: `1.64`)
* __Width__ ```Number```
* __Zoom__ ```Number``` (default Value: `0.23`)

